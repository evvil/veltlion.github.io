#!/system/bin/sh
#03-12-2015,by taera

#代理IP:
HOST="10.123.254.144"

#代理端口:
PORT="80"

#代理DNS ( y or n )
DNS=""

#排除
UID0=""

#禁网
UID1=""

#########START#########

#CLEAN
clean () {
	iptables -t nat -D OUTPUT -j SORA
	iptables -t nat -F SORA
	iptables -t nat -X SORA
	iptables -t nat -D PREROUTING -s 192.168.0.0/16 -j TETHERING
	iptables -t nat -F TETHERING
	iptables -t nat -X TETHERING
	iptables -D OUTPUT -j KINSHI
	iptables -F KINSHI
	iptables -X KINSHI
	killall redsocks
}
clean 2>/dev/null

iptables -t nat -N SORA

#IF ACCEPT
for i in lo wlan0 ppp0 tun0 ap0 usb0 rndis0; do
	iptables -t nat -A SORA -o $i -j ACCEPT
done

#DNS
if [[ $DNS == "y" ]]; then
	DNS="REDIRECT --to-port 5353"
else
	DNS="ACCEPT"
fi

#PROXY
iptables -t nat -A SORA -d $HOST -j ACCEPT
iptables -t nat -A SORA -p udp --dport 53 -j $DNS
iptables -t nat -A SORA -p tcp --dport 80 -j DNAT --to-destination $HOST:$PORT
##APP ACCEPT
for haru in $UID0; do
	iptables -t nat -A SORA -m owner --uid-owner $haru -j ACCEPT
done
iptables -t nat -A SORA -p tcp -j REDIRECT --to-port 56
iptables -t nat -A SORA ! -p tcp -j DNAT --to-destination $HOST:$PORT

#APP DROP
iptables -N KINSHI
iptables -I OUTPUT -j KINSHI
iptables -A KINSHI -m state --state INVALID -j DROP
for riko in $UID1; do
	iptables -A KINSHI -m owner --uid-owner $riko -j DROP
done

#TETHERING
iptables -t nat -N TETHERING
iptables -t nat -I PREROUTING -s 192.168.0.0/16 -j TETHERING
iptables -t nat -A TETHERING -d 192.168.0.0/16,224.0.0.0/24,239.255.255.250,$HOST -j ACCEPT
iptables -t nat -A TETHERING -p tcp --dport 80 -j DNAT --to-destination $HOST:$PORT
iptables -t nat -A TETHERING -p tcp -j REDIRECT --to-port 56
iptables -t nat -A TETHERING ! -p tcp -j DNAT --to-destination $HOST:$PORT

#REDSOCKS
echo "
base {
	log_debug = off;
	log_info = off;
	daemon = on; 
	redirector = iptables;
}

redsocks {
	local_ip = 0.0.0.0;
	local_port = 56;
	ip = $HOST;
	port = $PORT;
	type = http-connect;
}

dnstc {
	local_ip = 127.0.0.1;
	local_port = 5353;
}
" > /data/redsocks.conf

iptables -t nat -A OUTPUT -j SORA
redsocks -c /data/redsocks.conf

echo 已执行！

##########END##########

