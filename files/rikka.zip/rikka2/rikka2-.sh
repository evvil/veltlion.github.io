#!/system/bin/sh
#03-12-2015,by taera
#last update 04-18-2015

#CLEAN
clean () {
	iptables -t nat -D OUTPUT -j SORA
	iptables -t nat -F SORA
	iptables -t nat -X SORA
	iptables -t nat -D PREROUTING -s 192.168.0.0/16 -j TETHERING
	iptables -t nat -F TETHERING
	iptables -t nat -X TETHERING
	iptables -D OUTPUT -j KINSHI
	iptables -F KINSHI
	iptables -X KINSHI
	killall redsocks
}
clean 2>/dev/null

echo 已关闭！
