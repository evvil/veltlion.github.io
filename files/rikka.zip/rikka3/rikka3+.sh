#!/system/bin/sh
#03-14-2015, by taera.
#last update 08-09-2016

#代理IP: 河北联通: 10.123.113.80（未测试
HOST="10.123.254.144"

#代理端口:
PORT="80"

#指定代理网卡:
IF=

#DNS
DNS="8.8.8.8"

#只代理80端口的APP
UID0=""

#禁网
UID1=""

#共享设备UDP端口放行
UDPP=""

#########START#########

rikka=/data/rikka
it=iptables
itn="$it -t nat"
[ -d $rikka ] || mkdir $rikka
cd $rikka

#Chain
R() {
	for c in SORA rikka_IF rikka_PROXY rikka_AUA rikka_PRE; do
		$@ $c
	done
}

#CLEAN
clean() {
	$itn -D OUTPUT -j SORA
	$itn -D PREROUTING -s 192.168.0.0/16 -j rikka_PRE
	R $itn -F
	R $itn -X
	$it -D OUTPUT -j KINSHI
	$it -F KINSHI
	$it -X KINSHI
	for p in r.pid p.pid; do
		[ -e $p ] && kill `cat $p` && rm $p || killall pdnsd redsocks
	done
}

[[ `$itn -nL SORA 2>/dev/null` != '' ]] && clean 2>/dev/null

R $itn -N

#DNS
$itn -A SORA -p udp --dport 53 -j REDIRECT --to-port 5353

#IF SET
$itn -A SORA -j rikka_IF
if [ -z $IF ]; then
	for k in lo wlan0 ppp0 tun0 ap0 usb0 rndis0 bt-pan; do
		$itn -A rikka_IF -o $k -j ACCEPT
	done
else
	IF="-o $IF"
fi

#PROXY
$itn -A SORA $IF -j rikka_PROXY
$itn -A rikka_PROXY -d $HOST,127.0.0.1 -j ACCEPT
$itn -A rikka_PROXY -p tcp --dport 80 -j DNAT --to-destination $HOST:$PORT
$itn -A rikka_PROXY -p tcp -j REDIRECT --to-port 56
$itn -A rikka_PROXY ! -p tcp -j DNAT --to-destination $HOST:$PORT

#APP ACCEPT
if [[ $UID0 != ALL ]]; then
	for haru in $UID0; do
		$itn -I rikka_PROXY 3 -m owner --uid-owner $haru -j ACCEPT
	done
else
	$itn -I rikka_PROXY 3 -j ACCEPT
fi

#APP DROP
$it -N KINSHI
$it -I OUTPUT -j KINSHI
$it -A KINSHI -m state --state INVALID -j DROP
for riko in $UID1; do
	$it -A KINSHI -m owner --uid-owner $riko -j DROP
done

#TETHERING
$itn -I PREROUTING -s 192.168.0.0/16 -j rikka_PRE
$itn -A rikka_PRE -p udp --dport 53 -j REDIRECT --to-port 5353
$itn -A rikka_PRE -d 192.168.0.0/16,224.0.0.0/24,239.255.255.250,124.40.53.8,$HOST -j ACCEPT
$itn -A rikka_PRE -p tcp --dport 80 -j DNAT --to-destination $HOST:$PORT
$itn -A rikka_PRE -p tcp -j REDIRECT --to-port 56
if [[ $UDPP != ALL ]]; then
	for up in $UDPP; do
		$itn -A rikka_PRE -p udp --dport $up -j ACCEPT
done
else
	$itn -A rikka_PRE -p udp -j ACCEPT
fi
$itn -A rikka_PRE ! -p tcp -j DNAT --to-destination $HOST:$PORT


##CONF FILES

#PDNSD
echo "
global {
	perm_cache = 4096;
	run_as = root;
	pid_file = $rikka/p.pid;
	server_ip = any;
	server_port = 5353;
	query_method = tcp_udp;
	status_ctl = on;
	tcp_server = on;
	min_ttl = 1d;
	max_ttl = 1w;
	neg_ttl = 120s;
	paranoid = on;
	timeout = 10;
	randomize_recs = on;
	daemon = on;
}

server {
	label = DNS;
	ip = $DNS;
	port = 53;
	proxy_only = on;
	edns_query = on;
}

source {
	owner=localhost;
	serve_aliases=on;
	file=/system/etc/hosts;
}

rr { //Windows感叹号
	name = www.msftncsi.com;
	reverse = on;
	a = 124.40.53.8;
}
" >pdnsd.conf

#REDSOCKS
echo "
base {
	log_debug = off;
	log_info = off;
	daemon = on; 
	redirector = $it;
}

redsocks {
	local_ip = 0.0.0.0;
	local_port = 65;
	ip = $HOST;
	port = $PORT;
	type = http-relay; 
}

redsocks {
	local_ip = 0.0.0.0;
	local_port = 56;
	ip = $HOST;
	port = $PORT;
	type = http-connect;
}
" >redsocks.conf

chmod -R 644 $rikka
pdnsd || echo pdnsd启动失败！
redsocks -c $rikka/redsocks.conf -p $rikka/r.pid || echo redsocks启动失败！
$itn -I OUTPUT -j SORA
echo 已执行！

##########END##########
