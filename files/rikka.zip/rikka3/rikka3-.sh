#!/system/bin/sh
#03-14-2015, by taera.

rikka=/data/rikka
it=iptables
itn="$it -t nat"
[ -d $rikka ] || mkdir $rikka
cd $rikka

#CLEAN
clean() {
	$itn -D OUTPUT -j SORA
	$itn -D PREROUTING -s 192.168.0.0/16 -j rikka_PRE
	for c in SORA rikka_IF rikka_PROXY rikka_AUA rikka_PRE; do
		$itn -F $c
		$itn -X $c
	done
	$it -D OUTPUT -j KINSHI
	$it -F KINSHI
	$it -X KINSHI
	if [ -e r.pid ]; then
		kill `cat r.pid`
		rm r.pid
	else
		killall redsocks
	fi
	if [ -e p.pid ]; then
		kill `cat p.pid`
		rm p.pid
	else
		killall pdnsd
	fi
}

clean 2>/dev/null

echo 已关闭！
